import os


def human_read_format(size):
    c = 0
    bites = ["Б", "КБ", "МБ", "ГБ"]
    while size // 1024 > 0:
        size = size / 1024
        c += 1
    return f"{round(size)}{bites[c]}"


def get_ﬁles_sizes():
    files = []
    for el in name:
        for el1 in el[1:]:
            for el2 in el1:
                size = os.path.getsize(f"{el[0]}/{el2}")
                files.append(f"{el2} {human_read_format(size)}")
    return "\n".join(files)


name = os.walk(os.getcwd())

files_size = get_ﬁles_sizes()
print(files_size)
