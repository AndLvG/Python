#  Created by Artem Manchenkov
#  artyom@manchenkoff.me
#
#  Copyright © 2019
#
#  Примеры базового синтаксиса и работа с типами данных
#  Числа, строки, списки, булево значение
#

a = 1 + 2
a = a + a

integer_number = 10  # int
float_number = 10.4  # float

string_value = "Text"  # str
string_value = string_value * 2  # = TextText
string_value = string_value + string_value

string_value.lower()

numbers = [1, 2, 3, 4, "Test", 10.5]  # list

a = True  # bool
a = False

result = 10 > 5